-- SALES DATABASE ASSIGNMENT
-- PART 1: BASIC SQL

-- B01

SELECT *
FROM Customers;

SELECT FirstName, LastName, Country
FROM Customers;

-- B02
SELECT CustomerID, FirstName, LastName, Country
FROM Customers
WHERE Country = 'Germany';

-- B03
SELECT CustomerID, FirstName, LastName, Country, Score
FROM Customers
WHERE Score >= 300
AND Country IN ('Germany', 'France');

-- B04
SELECT ProductID, Product, Category, Price
FROM Products
ORDER BY Price DESC;

-- B05
SELECT Product, Price
FROM Products
WHERE Price BETWEEN 50 AND 300;

-- B06
SELECT ProductID, Product, Category, Price
FROM Products
WHERE Product LIKE '%Phone%';

-- B07
SELECT DISTINCT Category
FROM Products
ORDER BY Category;

-- B08
SELECT
	Customers.CustomerID,
	Customers.FirstName,
	Customers.LastName,
	Orders.OrderID,
	Orders.OrderDate,
	Orders.Sales
FROM Customers
INNER JOIN Orders
ON Customers.CustomerID = Orders.CustomerID;

-- B09
SELECT 
	OrderStatus,
	COUNT(*) AS OrderCount,
	SUM(Sales) AS TotalSales
FROM Orders
GROUP BY OrderStatus;

-- B10
INSERT INTO Products (ProductID, Product, Category, Price)
VALUES (999, 'Test Product', 'Electronics', 100);

-- Check
SELECT * 
FROM Products
WHERE ProductID = 999;

-- Update 
UPDATE Products
SET Price = 120
WHERE ProductID = 999;

-- Check Update 
SELECT *
FROM Products
WHERE ProductID = 999;

-- Delete 
DELETE FROM Products
WHERE ProductID = 999;

-- Verify
SELECT *
FROM Products
WHERE ProductID = 999;


-- Scenario 1: Customer loyalty and sales analysis

-- 1.1
SELECT
	FirstName,
	LastName,
	Country,
	Score
FROM Customers
WHERE Score > 500
ORDER BY Score DESC;

-- 1.2
SELECT 
	FirstName,
	LastName,
	Country,
	Score
FROM Customers
Where Country IN ('Germany', 'France', 'USA')
	AND Score >= 300;
	
-- 1.3
SELECT
	c.FirstName || ' ' || c.LastName AS CustomerName,
	o.OrderID,
	o.OrderDate,
	o.Sales
FROM Customers AS c
INNER JOIN Orders AS o
	ON c.CustomerID = o.CustomerID;
	
-- 1.4
SELECT
	c.CustomerID,
	c.FirstName,
	c.LastName,
	c.Country
FROM Customers AS c
LEFT JOIN Orders AS o
	ON c.CustomerID = o.CustomerID
WHERE o.OrderID IS NULL;

-- 1.5
SELECT 
	c.CustomerID,
	c.FirstName || ' ' || c.LastName AS CustomerName,
	SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o
	ON c.CustomerID = o.CustomerID
GROUP BY
	c.CustomerID,
	c.FirstName,
	c.LastName
ORDER BY 
	TotalSales DESC,
	c.CustomerID ASC;
	
-- 1.6
SELECT
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o
    ON c.CustomerID = o.CustomerID
GROUP BY
    c.CustomerID,
    c.FirstName,
    c.LastName
HAVING SUM(o.Sales) > 1000
ORDER BY
    TotalSales DESC,
    c.CustomerID ASC;
	
-- 1.7
SELECT
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    SUM(o.Sales) AS TotalSales
FROM Customers AS c
INNER JOIN Orders AS o
    ON c.CustomerID = o.CustomerID
GROUP BY
    c.CustomerID,
    c.FirstName,
    c.LastName,
    c.Country
ORDER BY
    TotalSales DESC,
    c.CustomerID ASC
LIMIT 5;


-- SCENARIO 2: ORDER AND DELIVERY INVESTIGATION

-- 2.1 

SELECT
    OrderID,
    CustomerID,
    OrderDate,
    ShipDate,
    OrderStatus
FROM Orders
WHERE OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
ORDER BY OrderDate;

-- 2.2

SELECT *
FROM Orders
WHERE OrderStatus = 'Pending'
ORDER BY OrderDate ASC;

-- 2.3

SELECT
    o.OrderID,
    c.FirstName,
    c.LastName,
    o.OrderDate,
    o.ShipDate
FROM Orders AS o
INNER JOIN Customers AS c
    ON o.CustomerID = c.CustomerID
WHERE o.ShipDate IS NOT NULL
AND julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY o.OrderID;

-- 2.4

SELECT DISTINCT
    c.FirstName,
    c.LastName,
    c.Country
FROM Customers AS c
INNER JOIN Orders AS o
    ON c.CustomerID = o.CustomerID
WHERE o.ShipDate IS NOT NULL
AND julianday(o.ShipDate) - julianday(o.OrderDate) > 7
ORDER BY c.Country, c.LastName;

-- Preparation for Scenario 2.5, 2.6 and 2.7

INSERT OR IGNORE INTO Orders
(OrderID, ProductID, CustomerID, SalesPersonID, OrderDate, ShipDate, OrderStatus, ShipAddress, BillAddress, Quantity, Sales, CreationTime)

VALUES
(105, 101, 1, 11, '2026-11-01', NULL, 'Pending', '10 Nizami St, Baku', '10 Nizami St, Baku', 1, 55.00, '2026-11-01 10:00:00'),

(110, 102, 2, 12, '2026-11-02', NULL, 'Pending', NULL, '45 Main St, New York', 1, 230.00, '2026-11-02 10:00:00'),

(999, 103, 3, 12, '2026-11-03', NULL, 'Pending', NULL, NULL, 1, 850.00, '2026-11-03 10:00:00');

SELECT *
FROM Orders
WHERE OrderID IN (105, 110, 999)
ORDER BY OrderID;

-- 2.5

SELECT *
FROM Orders
WHERE OrderID = 105;

UPDATE Orders
SET
    OrderStatus = 'Shipped',
    ShipDate = '2026-11-05'
WHERE OrderID = 105;

SELECT *
FROM Orders
WHERE OrderID = 105;

-- 2.6
SELECT *
FROM Orders
WHERE OrderID = 110;

UPDATE Orders
SET ShipAddress = '45 Main Street, Baku'
WHERE OrderID = 110;

SELECT *
FROM Orders
WHERE OrderID = 110;

-- 2.7

SELECT *
FROM Orders
WHERE OrderID = 999;

DELETE FROM Orders
WHERE OrderID = 999;

SELECT *
FROM Orders
WHERE OrderID = 999;


-- 2.8

SELECT
    OrderStatus,
    COUNT(*) AS OrderCount
FROM Orders
GROUP BY OrderStatus
ORDER BY OrderCount DESC;

-- 2.9 

SELECT
    o.OrderID,
    c.FirstName,
    c.LastName,
    o.OrderDate,
    o.OrderStatus
FROM Orders AS o
INNER JOIN Customers AS c
    ON o.CustomerID = c.CustomerID
WHERE o.ShipDate IS NULL
ORDER BY o.OrderDate;


SCENARIO 3: Products and employee performance

-- 3.1

SELECT 
    Product, 
    Category, 
    Price
FROM Products
WHERE Price BETWEEN 50 AND 300
ORDER BY Price ASC;

--3.2

SELECT 
    ProductID, 
    Product, 
    Category, 
    Price
FROM Products
WHERE Category = 'Electronics' 
  AND Price > 500;
  
-- 3.3

SELECT 
    p.Product, 
    p.Category, 
    o.Quantity, 
    o.Sales
FROM Products p
INNER JOIN Orders o ON p.ProductID = o.ProductID;

-- 3.4

SELECT 
    p.ProductID,
    p.Product, 
    SUM(o.Quantity) AS TotalQuantity
FROM Products p
INNER JOIN Orders o ON p.ProductID = o.ProductID
GROUP BY p.ProductID, p.Product
ORDER BY TotalQuantity DESC, p.ProductID ASC
LIMIT 5;

-- 3.5

SELECT 
    p.ProductID, 
    p.Product, 
    p.Category, 
    p.Price
FROM Products p
LEFT JOIN Orders o ON p.ProductID = o.ProductID
WHERE o.OrderID IS NULL;
 
 
-- 3.6

SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    e.Department,
    SUM(o.Sales) AS TotalSales
FROM Employees e
INNER JOIN Orders o ON e.EmployeeID = o.SalesPersonID
GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Department;

-- 3.7 

SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    e.Department,
    SUM(o.Sales) AS TotalSales
FROM Employees e
INNER JOIN Orders o ON e.EmployeeID = o.SalesPersonID
GROUP BY e.EmployeeID, e.FirstName, e.LastName, e.Department
HAVING SUM(o.Sales) > 5000
ORDER BY TotalSales DESC, e.EmployeeID ASC;

-- 3.8

INSERT INTO Products (ProductID, Product, Category, Price)
VALUES (501, 'Wireless Keyboard', 'Electronics', 75.00);

SELECT * FROM Products WHERE ProductID = 501;

-- 3.9
UPDATE Products
SET Price = 90.00
WHERE ProductID = 501;

SELECT * FROM Products WHERE ProductID = 501;

-- 3.10

ALTER TABLE Products
ADD COLUMN StockQuantity INTEGER;

SELECT * FROM Products;

-- 3.11

SELECT FirstName, LastName FROM Customers
UNION
SELECT FirstName, LastName FROM Employees;

-- 3.12

SELECT 
    p.Category,
    SUM(o.Quantity) AS TotalQuantity,
    SUM(o.Sales) AS TotalSales
FROM Products p
INNER JOIN Orders o ON p.ProductID = o.ProductID
GROUP BY p.Category
HAVING SUM(o.Sales) > 2000
ORDER BY TotalSales DESC;


-- SCENARIO 4: Targeted campaign planning

-- 4.1
SELECT 
    o.OrderID,
    o.OrderDate,
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    p.Product,
    p.Category,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    o.Quantity,
    o.Sales
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
  AND c.Country IN ('Germany', 'France', 'USA')
ORDER BY c.Country ASC, o.OrderDate ASC, o.OrderID ASC;

-- 4.2

SELECT 
    o.OrderID,
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    c.Score,
    p.Product,
    o.Sales
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
  AND c.Country IN ('Germany', 'France', 'USA')
  AND p.Category = 'Electronics'
  AND (c.Score >= 500 OR o.Sales >= 1000);
  
-- 4.3
 
SELECT 
    ProductID,
    Product,
    Category,
    Price
FROM Products
WHERE Category = 'Electronics'
  AND Price BETWEEN 40 AND 100
  AND (Product LIKE '%Wireless%' OR Product LIKE '%USB%')
ORDER BY Price ASC, ProductID ASC;

-- 4.4

SELECT DISTINCT
    c.CustomerID,
    c.FirstName,
    c.LastName,
    c.Country,
    c.Score
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND c.Score >= 500
  AND p.Category = 'Electronics'
  AND o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31';
  

-- 4.5

SELECT 
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    COUNT(o.OrderID) AS OrderCount,
    SUM(o.Quantity) AS TotalQuantity,
    SUM(o.Sales) AS TotalSales
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(o.OrderID) >= 2 
   AND SUM(o.Sales) >= 1000
ORDER BY TotalSales DESC, c.CustomerID ASC;

-- 4.6

SELECT 
    c.Country,
    p.Category,
    COUNT(o.OrderID) AS OrderCount,
    SUM(o.Quantity) AS TotalQuantity,
    SUM(o.Sales) AS TotalSales
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY c.Country, p.Category
HAVING SUM(o.Sales) > 500;

-- 4.7

SELECT 
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    c.Score
FROM Customers c
LEFT JOIN Orders o 
    ON c.CustomerID = o.CustomerID
   AND o.OrderStatus IN ('Shipped', 'Delivered')
   AND o.ShipDate IS NOT NULL
   AND o.ShipDate >= o.OrderDate
   AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND o.OrderID IS NULL;
  

-- 4.8

SELECT c.CustomerID
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND p.Category = 'Electronics'
  AND o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
INTERSECT
SELECT c.CustomerID
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE c.Country IN ('Germany', 'France', 'USA')
  AND p.Category = 'Furniture'
  AND o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31';
  
  
-- 4.9

SELECT CustomerID FROM (
    SELECT c.CustomerID
    FROM Customers c
    INNER JOIN Orders o ON c.CustomerID = o.CustomerID
    INNER JOIN Products p ON o.ProductID = p.ProductID
    WHERE c.Country IN ('Germany', 'France', 'USA')
      AND p.Category = 'Electronics'
      AND o.OrderStatus IN ('Shipped', 'Delivered')
      AND o.ShipDate IS NOT NULL
      AND o.ShipDate >= o.OrderDate
      AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
    UNION
    SELECT c.CustomerID
    FROM Customers c
    INNER JOIN Orders o ON c.CustomerID = o.CustomerID
    INNER JOIN Products p ON o.ProductID = p.ProductID
    WHERE c.Country IN ('Germany', 'France', 'USA')
      AND p.Category = 'Furniture'
      AND o.OrderStatus IN ('Shipped', 'Delivered')
      AND o.ShipDate IS NOT NULL
      AND o.ShipDate >= o.OrderDate
      AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
ORDER BY CustomerID ASC;

-- 4.10

SELECT CustomerID FROM (
    SELECT c.CustomerID
    FROM Customers c
    INNER JOIN Orders o ON c.CustomerID = o.CustomerID
    INNER JOIN Products p ON o.ProductID = p.ProductID
    WHERE c.Country IN ('Germany', 'France', 'USA')
      AND p.Category = 'Electronics'
      AND o.OrderStatus IN ('Shipped', 'Delivered')
      AND o.ShipDate IS NOT NULL
      AND o.ShipDate >= o.OrderDate
      AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
    EXCEPT
    SELECT c.CustomerID
    FROM Customers c
    INNER JOIN Orders o ON c.CustomerID = o.CustomerID
    INNER JOIN Products p ON o.ProductID = p.ProductID
    WHERE c.Country IN ('Germany', 'France', 'USA')
      AND p.Category = 'Furniture'
      AND o.OrderStatus IN ('Shipped', 'Delivered')
      AND o.ShipDate IS NOT NULL
      AND o.ShipDate >= o.OrderDate
      AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
ORDER BY CustomerID ASC;


-- SCENARIO 5: Fulfilment exception desk


-- 5.1. 
SELECT 
    o.OrderID,
    o.OrderDate,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    p.Product,
    o.Quantity,
    o.Sales,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    o.ShipAddress
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
ORDER BY o.OrderDate ASC, o.OrderID ASC;

-- 5.2. 
SELECT 
    o.OrderID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    o.OrderDate,
    p.Product,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    o.Sales
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate < '2026-10-31';

-- 5.3. 
SELECT 
    o.OrderID,
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    o.ShipAddress
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
  AND (o.ShipAddress IS NULL OR TRIM(o.ShipAddress) = '');

-- 5.4.
SELECT 
    o.OrderID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    o.ShipAddress,
    o.BillAddress,
    o.OrderStatus
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipAddress IS NOT NULL AND TRIM(o.ShipAddress) <> ''
  AND o.BillAddress IS NOT NULL AND TRIM(o.BillAddress) <> ''
  AND o.ShipAddress <> o.BillAddress;

-- 5.5.
SELECT 
    o.OrderID,
    o.OrderStatus,
    o.OrderDate,
    o.ShipDate,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    e.FirstName || ' ' || e.LastName AS EmployeeName
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderDate <= '2026-11-07'
  AND (
      o.ShipDate < o.OrderDate
      OR (o.OrderStatus IN ('Shipped', 'Delivered') AND o.ShipDate IS NULL)
  );


-- 5.6. 
SELECT 
    o.OrderID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    p.Product,
    o.OrderDate,
    o.ShipDate,
    CAST(julianday(o.ShipDate) - julianday(o.OrderDate) AS INTEGER) AS DaysToShip
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND (julianday(o.ShipDate) - julianday(o.OrderDate)) > 7
ORDER BY DaysToShip DESC, o.OrderID ASC;

-- 5.7. 
SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    COUNT(o.OrderID) AS PendingOrderCount,
    COALESCE(SUM(o.Sales), 0) AS PendingSales
FROM Employees e
LEFT JOIN Orders o 
    ON e.EmployeeID = o.SalesPersonID
   AND o.OrderStatus = 'Pending'
   AND o.ShipDate IS NULL
   AND o.OrderDate <= '2026-11-07'
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName;

-- 5.8. 
SELECT 
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    COUNT(o.OrderID) AS PendingOrderCount,
    SUM(o.Sales) AS PendingSales
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
WHERE o.OrderStatus = 'Pending'
  AND o.ShipDate IS NULL
  AND o.OrderDate <= '2026-11-07'
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(o.OrderID) >= 2;

-- 5.9. 
SELECT 
    o.OrderID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    p.Product,
    o.Sales,
    o.OrderStatus,
    o.OrderDate,
    o.ShipDate
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
WHERE o.OrderStatus <> 'Cancelled'
  AND o.OrderDate <= '2026-11-07'
  AND c.Country IN ('Germany', 'USA')
  AND o.Sales >= 500
  AND (
      (o.OrderStatus = 'Pending' AND o.ShipDate IS NULL)
      OR (o.ShipDate IS NOT NULL AND o.ShipDate >= o.OrderDate AND (julianday(o.ShipDate) - julianday(o.OrderDate)) > 7)
  );

-- 5.10.
SELECT 
    o.OrderID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    c.Country,
    p.Product,
    o.Quantity,
    o.ShipAddress,
    e.FirstName || ' ' || e.LastName AS EmployeeName
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Products p ON o.ProductID = p.ProductID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus = 'Pending'
  AND o.OrderDate <= '2026-11-07'
  AND o.ShipDate IS NULL
  AND o.ShipAddress IS NOT NULL
  AND TRIM(o.ShipAddress) <> ''
ORDER BY c.Country ASC, o.OrderDate ASC, o.OrderID ASC;


-- SCENARIO 6: Sales team review and retention


-- 6.1
SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    e.Department,
    e.ManagerID,
    m.FirstName || ' ' || m.LastName AS ManagerName
FROM Employees e
LEFT JOIN Employees m ON e.ManagerID = m.EmployeeID;

-- 6.2
SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    COUNT(o.OrderID) AS OrderCount,
    COALESCE(SUM(o.Quantity), 0) AS TotalQuantity,
    COALESCE(SUM(o.Sales), 0) AS TotalSales
FROM Employees e
LEFT JOIN Orders o 
    ON e.EmployeeID = o.SalesPersonID
   AND o.OrderStatus IN ('Shipped', 'Delivered')
   AND o.ShipDate IS NOT NULL
   AND o.ShipDate >= o.OrderDate
   AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
ORDER BY TotalSales DESC, e.EmployeeID ASC;

-- 6.3
SELECT 
    m.EmployeeID AS ManagerID,
    m.FirstName || ' ' || m.LastName AS ManagerName,
    COUNT(DISTINCT e.EmployeeID) AS DirectSalesStaffCount,
    COUNT(o.OrderID) AS TeamOrderCount,
    COALESCE(SUM(o.Sales), 0) AS TeamSales
FROM Employees m
INNER JOIN Employees e 
    ON m.EmployeeID = e.ManagerID
   AND e.Department = 'Sales'
LEFT JOIN Orders o 
    ON e.EmployeeID = o.SalesPersonID
   AND o.OrderStatus IN ('Shipped', 'Delivered')
   AND o.ShipDate IS NOT NULL
   AND o.ShipDate >= o.OrderDate
   AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY m.EmployeeID, m.FirstName, m.LastName;

-- 6.4
SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    COUNT(o.OrderID) AS OrderCount,
    SUM(o.Sales) AS TotalSales
FROM Employees e
INNER JOIN Orders o ON e.EmployeeID = o.SalesPersonID
WHERE e.Department = 'Sales'
  AND o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
GROUP BY e.EmployeeID, e.FirstName, e.LastName
HAVING COUNT(o.OrderID) >= 2 
   AND SUM(o.Sales) >= 1000
ORDER BY TotalSales DESC, e.EmployeeID ASC;

-- 6.5
SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    COUNT(DISTINCT o.CustomerID) AS DistinctCustomers,
    COUNT(DISTINCT c.Country) AS DistinctCountries
FROM Employees e
LEFT JOIN Orders o 
    ON e.EmployeeID = o.SalesPersonID
   AND o.OrderStatus IN ('Shipped', 'Delivered')
   AND o.ShipDate IS NOT NULL
   AND o.ShipDate >= o.OrderDate
   AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
LEFT JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE e.Department = 'Sales'
GROUP BY e.EmployeeID, e.FirstName, e.LastName;


-- 6.6
SELECT 
    e.EmployeeID,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    e.Department
FROM Employees e
LEFT JOIN Orders o 
    ON e.EmployeeID = o.SalesPersonID
   AND o.OrderStatus IN ('Shipped', 'Delivered')
   AND o.ShipDate IS NOT NULL
   AND o.ShipDate >= o.OrderDate
   AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
WHERE e.Department = 'Sales'
  AND o.OrderID IS NULL;

-- 6.7
SELECT CustomerID FROM (
    SELECT CustomerID
    FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
    INTERSECT
    SELECT CustomerID
    FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
)
ORDER BY CustomerID ASC;

-- 6.8
SELECT CustomerID FROM (
    SELECT CustomerID
    FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
    EXCEPT
    SELECT CustomerID
    FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
)
ORDER BY CustomerID ASC;

-- 6.9
SELECT CustomerID FROM (
    SELECT CustomerID
    FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-11-01' AND '2026-11-07'
    EXCEPT
    SELECT CustomerID
    FROM Orders
    WHERE OrderStatus IN ('Shipped', 'Delivered')
      AND ShipDate IS NOT NULL
      AND ShipDate >= OrderDate
      AND OrderDate BETWEEN '2026-10-01' AND '2026-10-31'
)
ORDER BY CustomerID ASC;

-- 6.10
SELECT 
    'October 2026' AS PeriodLabel,
    o.OrderID,
    o.OrderDate,
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    o.Sales
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-10-01' AND '2026-10-31'

UNION ALL

SELECT 
    'November 01-07' AS PeriodLabel,
    o.OrderID,
    o.OrderDate,
    c.CustomerID,
    c.FirstName || ' ' || c.LastName AS CustomerName,
    e.FirstName || ' ' || e.LastName AS EmployeeName,
    o.Sales
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN Employees e ON o.SalesPersonID = e.EmployeeID
WHERE o.OrderStatus IN ('Shipped', 'Delivered')
  AND o.ShipDate IS NOT NULL
  AND o.ShipDate >= o.OrderDate
  AND o.OrderDate BETWEEN '2026-11-01' AND '2026-11-07'

ORDER BY OrderDate ASC, OrderID ASC;

